9ccb0311 Final MVP layout and routing cleanup
f4b6df6a Final MVP layout and routing cleanup
1d316102 Refactor: Clean codebase for type safety and integrity
fa9bbe35 Remove non-MVP code for launch
bc0c8c55 Remove non-MVP code and tests
87266cf4 Refactor: Implement homepage cleanup and component creation
e5f0928b 🧹 Clean merge conflict in ManualLookup.tsx
395776d9 ✅ Unified VehicleFoundCard: kept shared version, removed legacy files, injected into all result flows with safe conditions
8de15e19 🔧 Fix: Clean merge and logic refinement in carfaxCalculator.ts (validated fallback & uplift)
aa7b5e11 🔧 Fix: Fully resolved merge conflict in conditionCalculator.ts (FANG-standard clean merge)
1f52aa4f fix: merge valuation result page and detail page, types cleanup, Vite config restore
34302189 Remove pill selector from FeaturesTab
cd83ebbd Remove legacy follow-up files
46642211 Remove key features section from landing page
16be4647 🧹 FANG-Grade Routing Cleanup Phase 1
74d5a32b Audit for MakeModelSelect duplicates
b859823e Fix: Remove created_at from initial state
963f6c70 Fix: Remove unused initialData prop from UnifiedFollowUpForm
f53b8d67 Fix: Remove nested router instances
826bc44b Fix: Remove nested Router components
4b1613c6 Fix: Remove nested router
ad502c41 feat: Migrate to UnifiedAuthPage and cleanup
5a87fe16 Remove broken scraper scripts and empty folders
fb5248e6 Refactor: Remove outdated scraper files
fd2d7e1d Fix: Remove temporary fields and fix model population
2ef57a45 Remove unused follow-up question files
0341ead6 Remove unused files
64938ff3 Fix: Remove duplicate useAuth hook
8196f925 Refactor: Remove duplicate auth components and routes
fae229b2 chore: Clean up code and apply linting fixes
8183a290 chore: full repo cleanup
0ed538bf fix: separate and clean ManualEntryForm versions
4c85be8d Remove mock and test files
e85645a7 Clean up and lock down phase 1
0f6981f3 Remove unused files
c05a83d0 Fix: Remove nested BrowserRouter
f9e86fc7 Fix: Remove unreachable code in ServiceStatus
6f57410b Fix: Remove nested BrowserRouter
a4c49b07 Fix: Remove unintended sidebar
d4d4a4ea Refactor: Clean up and consolidate routes
6db7a1bb Fix: UseAuth import and file cleanup
1d2292f9 Refactor: Clean up auth files and routes
49ba5200 Remove duplicate VinDecoderResults.tsx
d7d19acc Fix: Remove duplicate PhotoUploadStep declaration
486684d6 Fix core issues and clean up codebase
133c107a Fix: Remove invalid toast properties
438f4856 Fix: Remove nested Router components
0df10ef7 Fix: Remove extraneous props in AuthForm
d6a2ad50 Replace broken npm-shrinkwrap.json with clean package-lock.json
af466403 Refactor: Remove unused code and restore pages
c0c9bf3c Remove useAuth.ts and rename auth pages
a5aa5413 Fix: Remove nested Router components
18a48c53 Fix: Resolve duplicate attribute error in carousel
59c293a1 Fix: Remove duplicate content in homepage
ee1fd6e6 Refactor: Deduplicate UI components and types
6d1bf6c2 Delete unused duplicate files
6cf0813e Add edit and delete actions to inventory table
575d3ca0 Refactor: Make DeleteConfirmationDialog reusable
acdc686e Remove error display logic
ef4b6fee Delete requirements.txt
7a63a51e Fix: Remove redundant vehicle lookup step
03bf5035 Refactor: Remove unnecessary code
b688a99a Fix: Remove duplicate lookup components
b2a04606 Remove duplicate VIN validation code
ac5e421a Remove corrupted validation files
651a68f9 Remove and recreate enhanced validation file
d97755d3 Fix: Remove shebang from generate-test-data.ts
95cebf10 Fix: Resolve duplicate links and view issues
abba71cc Fix: Remove invalid PDF text option
f8372a1f Fix: Remove non-existent test file
d5f9a6d2 Remove useEpaMpg test file
f6df769d Fix: Remove nested BrowserRouter
85b5844d Refactor: Remove duplicate files and folders
69b44a30 Refactor: remove mock data from useVehicleData.ts and use Supabase
0e8e074e Refactor: Apply code formatting and cleanup
c2940469 Refactor: Remove fallback/mock vehicle data
85e9794c Remove unused vehicle data functions
5d252dd9 Refactor: Remove unnecessary code
65a354e5 Refactor: Remove unused code
ac28c61c Refactor: Remove unused code
d623efde Remove unused code
ad22c1c6 Remove unused code
b8963cd5 Remove lookup links from navbar
5d48d437 Fix: Implement duplicate account checks
