// Export footer components
export * from "../layout/Footer";
