// src/components/home/KeyFeatures.tsx
import React from "react";

export const KeyFeatures = () => (
  <div>
    <h2>Key Features</h2>
    <ul>
      <li>Feature 1: Fast License Plate Lookup</li>
      <li>Feature 2: Vehicle Comparison</li>
      <li>Feature 3: Easy to Use</li>
    </ul>
  </div>
);
