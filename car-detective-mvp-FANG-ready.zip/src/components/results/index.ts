
export { ValuationResultCard } from './ValuationResultCard';
