
// Fallback Rollup configuration to force JavaScript-only version
export default {
  // Force Rollup to use the pure JavaScript implementation
  preferBuiltins: false,
  external: [],
  plugins: [],
}
